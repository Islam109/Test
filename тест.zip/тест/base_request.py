import requests
import json
from datetime import datetime

class BaseRequest:
    def __init__(self, base_url):
        self.base_url = base_url

    def _print_response(self, request_type, response):
        """Компактный и красивый вывод"""
        print(f"\n🔹 {request_type} {response.url}")
        print(f"   📊 Статус: {response.status_code} - {response.reason}")
        
        if response.text:
            try:
                response_data = response.json()
                
                # Для разных типов ответов показываем разную информацию
                if request_type == 'GET':
                    if 'id' in response_data and 'name' in response_data:
                        print(f"   🐾 ID: {response_data['id']}, Имя: {response_data['name']}")
                    elif 'id' in response_data and 'username' in response_data:
                        print(f"   👤 ID: {response_data['id']}, Пользователь: {response_data['username']}")
                    elif isinstance(response_data, dict) and len(response_data) > 5:
                        print(f"   📦 Получено {len(response_data)} элементов")
                    else:
                        print(f"   📦 {json.dumps(response_data, ensure_ascii=False)}")
                        
                elif request_type in ['POST', 'PUT', 'DELETE']:
                    if 'message' in response_data:
                        print(f"   ✅ {response_data['message']}")
                    else:
                        print(f"   📦 {json.dumps(response_data, ensure_ascii=False)}")
                        
            except json.JSONDecodeError:
                if len(response.text) < 100:
                    print(f"   📄 {response.text}")
                else:
                    print(f"   📄 Ответ получен ({len(response.text)} символов)")
        
        print("   " + "─" * 50)
        return response

    def _request(self, url, request_type, data=None, expected_error=False, headers=None):
        if headers is None:
            headers = {'Content-Type': 'application/json'}
        
        stop_flag = False
        while not stop_flag:
            if request_type == 'GET':
                response = requests.get(url, headers=headers)
            elif request_type == 'POST':
                response = requests.post(url, json=data, headers=headers)
            elif request_type == 'PUT':
                response = requests.put(url, json=data, headers=headers)
            else:
                response = requests.delete(url, headers=headers)

            if not expected_error and response.status_code == 200:
                stop_flag = True
            elif expected_error:
                stop_flag = True

        return self._print_response(request_type, response)

    def get(self, endpoint, endpoint_id, expected_error=False):
        url = f'{self.base_url}/{endpoint}/{endpoint_id}'
        response = self._request(url, 'GET', expected_error=expected_error)
        return response.json() if response.text else {}

    def post(self, endpoint, endpoint_id, body):
        url = f'{self.base_url}/{endpoint}/{endpoint_id}'
        response = self._request(url, 'POST', data=body)
        return response.json() if response.text else {}

    def delete(self, endpoint, endpoint_id):
        url = f'{self.base_url}/{endpoint}/{endpoint_id}'
        response = self._request(url, 'DELETE')
        return response.json() if response.text else {}
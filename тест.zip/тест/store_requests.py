from base_request import BaseRequest

class StoreRequests:
    def __init__(self, base_url):
        self.base_request = BaseRequest(base_url)
    
    def get_inventory(self):
        """Get inventory - GET /store/inventory"""
        url = f'{self.base_request.base_url}/store/inventory'
        response = self.base_request._request(url, 'GET')
        return response.json()
    
    def place_order(self, order_data):
        """Place order - POST /store/order"""
        url = f'{self.base_request.base_url}/store/order'
        response = self.base_request._request(url, 'POST', data=order_data)
        return response.json()
    
    def get_order_by_id(self, order_id):
        """Get order by ID - GET /store/order/{orderId}"""
        return self.base_request.get('store/order', order_id)
    
    def delete_order(self, order_id):
        """Delete order - DELETE /store/order/{orderId}"""
        return self.base_request.delete('store/order', order_id)

# Тестирование
if __name__ == "__main__":
    BASE_URL = 'https://petstore.swagger.io/v2'
    store_api = StoreRequests(BASE_URL)
    
    # Тест получения заказа
    order_info = store_api.get_order_by_id(1)
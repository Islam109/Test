from user_requests import UserRequests
from store_requests import StoreRequests

def test_all_requests():
    BASE_URL = 'https://petstore.swagger.io/v2'
    
    print("🚀 ТЕСТИРОВАНИЕ API PETSTORE")
    print("=" * 40)
    
    # Тестирование User API
    print("\n👤 USER API")
    user_api = UserRequests(BASE_URL)
    
    # 1. Создание пользователя
    user_data = {
        "id": 123,
        "username": "john_doe",
        "firstName": "John",
        "lastName": "Doe",
        "email": "john@example.com",
        "password": "password123",
        "phone": "1234567890",
        "userStatus": 1
    }
    created_user = user_api.create_user(user_data)
    
    # 2. Получение пользователя
    user_info = user_api.get_user_by_username("john_doe")
    
    # 3. Обновление пользователя
    updated_data = user_data.copy()
    updated_data["firstName"] = "Johnny"
    updated_user = user_api.update_user("john_doe", updated_data)
    
    # 4. Удаление пользователя
    delete_result = user_api.delete_user("john_doe")
    
    # Тестирование Store API
    print("\n🏪 STORE API")
    store_api = StoreRequests(BASE_URL)
    
    # 1. Получение инвентаря
    inventory = store_api.get_inventory()
    
    # 2. Создание заказа
    order_data = {
        "id": 1,
        "petId": 1,
        "quantity": 1,
        "shipDate": "2024-01-01T10:00:00.000Z",
        "status": "placed",
        "complete": True
    }
    placed_order = store_api.place_order(order_data)
    
    # 3. Получение заказа
    order_info = store_api.get_order_by_id(1)
    
    # 4. Удаление заказа
    delete_result = store_api.delete_order(1)
    
    print("\n✅ ВСЕ ТЕСТЫ ЗАВЕРШЕНЫ!")

if __name__ == "__main__":
    test_all_requests()
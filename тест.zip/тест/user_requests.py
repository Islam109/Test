from base_request import BaseRequest

class UserRequests:
    def __init__(self, base_url):
        self.base_request = BaseRequest(base_url)
    
    def create_user(self, user_data):
        """Create user - POST /user"""
        url = f'{self.base_request.base_url}/user'
        response = self.base_request._request(url, 'POST', data=user_data)
        return response.json()
    
    def get_user_by_username(self, username):
        """Get user by username - GET /user/{username}"""
        return self.base_request.get('user', username)
    
    def update_user(self, username, user_data):
        """Update user - PUT /user/{username}"""
        url = f'{self.base_request.base_url}/user/{username}'
        response = self.base_request._request(url, 'PUT', data=user_data)
        return response.json()
    
    def delete_user(self, username):
        """Delete user - DELETE /user/{username}"""
        return self.base_request.delete('user', username)

# Тестирование
if __name__ == "__main__":
    BASE_URL = 'https://petstore.swagger.io/v2'
    user_api = UserRequests(BASE_URL)
    
    # Тест получения пользователя
    user_info = user_api.get_user_by_username("testuser")